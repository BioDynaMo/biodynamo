Vc version / revision | Operating System | Compiler & Version | Compiler Flags | Assembler & Version | CPU
----------------------|------------------|--------------------|----------------|---------------------|----
                      |                  |                    |                |                     |

## Testcase
```cpp
```

## Actual Results

## Expected Results
