/*
 * Distributed under OSI-approved BSD 3-Clause License. See
 * accompanying License.txt
 */
#ifndef catalyst_h
#define catalyst_h

#include "catalyst_api.h"
#include "catalyst_export.h"
#include "catalyst_version.h"

#endif // #ifndef catalyst_h
