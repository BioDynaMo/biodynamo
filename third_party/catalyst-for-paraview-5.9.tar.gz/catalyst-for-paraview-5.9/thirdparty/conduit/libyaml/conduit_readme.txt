
2019/05/08

Source extracted from the libyaml repo: 

https://github.com/yaml/libyaml

Hash: 690a781 (https://github.com/yaml/libyaml/commit/690a781ef6af70ce6749d6e2be91743345123998)

License: MIT
