This is a subset of rapidjson from github master b39a898 (~Oct 30, 2015)

We use rapidjson internally as a header only library - the build system parts, tests, etc were removed since they are not used. 

