Third Party Licenses
====================

For a list of software components used in Conduit and their respective licenses
refer to:

* [The live documentation](http://software.llnl.gov/conduit/licenses.html#third-party-builtin-libraries)
* [The source code](/src/docs/sphinx/licenses.rst )
