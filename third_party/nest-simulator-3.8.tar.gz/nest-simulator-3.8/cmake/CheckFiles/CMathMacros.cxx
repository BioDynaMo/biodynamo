#undef __PURE_CNAME
#include <cmath>
#define __PURE_CNAME

double e( M_E );
double pi( M_PI );

int main(int argc, char const *argv[])
{
  return 0;
}
