# CI and build support files

This directory contains helper scripts for the CI build process, for checking
the code style of NEST.
