# `lib` folder

The library files for SLI and NEST. This includes the startup-files and SLI-wrappers for built-in functions.
