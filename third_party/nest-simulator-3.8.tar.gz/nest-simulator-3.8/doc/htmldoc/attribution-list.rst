:orphan:

Attribution for images, icons, diagrams
=======================================

Custom images
-------------

The following images were created by  *A. Fischer - INM-6 Forschungszentrum Juelich GmBH*

* neuron.svg
* synapse.svg
* networkbrainlight.svg
* stimulatelight.svg
* recordinglight.svg

For use in Forschungszentrum Juelich GmBH. Cite the author of the work if using.

Icons provided by Flaticon
--------------------------

* <a href="https://www.flaticon.com/free-icons/neuron" title="neuron icons">Neuron icons created by Nadiinko - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/neuron" title="neuron icons">Neuron icons created by Freepik - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/monitor" title="monitor icons">Monitor icons created by Icongeek26 - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/dictionary" title="dictionary icons">Dictionary icons created by Freepik - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/neuron" title="neuron icons">Neuron icons created by Freepik - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/chat" title="chat icons">Chat icons created by Freepik - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/user" title="user icons">User icons created by Freepik - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/data-science" title="data science icons">Data science icons created by Eucalyp - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/brain" title="brain icons">Brain icons created by Freepik - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/teacher" title="teacher icons">Teacher icons created by Good Ware - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/math" title="math icons">Math icons created by Freepik - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/data-storage" title="data storage icons">Data storage icons created by IconLauk - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/version" title="version icons">Version icons created by Ahmad Roaayala - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/developer" title="developer icons">Developer icons created by Freepik - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/cloud-computing" title="cloud computing icons">Cloud computing icons created by Prosymbols Premium - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/teacher" title="teacher icons">Teacher icons created by Freepik - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/launch" title="launch icons">Launch icons created by Freepik - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/conversation" title="conversation icons">Conversation icons created by Freepik - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/quotation-marks" title="quotation marks icons">Quotation marks icons created by Retinaicons - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/quote" title="quote icons">Quote icons created by DinosoftLabs - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/mail" title="mail icons">Mail icons created by Freepik - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/external-link" title="external link icons">External link icons created by Bharat Icons - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/checklist" title="checklist icons">Checklist icons created by juicy_fish - Flaticon</a>
* <a href="https://www.flaticon.com/free-icons/scientist" title="scientist icons">Scientist icons created by Victoruler - Flaticon</a>
