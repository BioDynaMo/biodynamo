.. _connect_index:

Connect NEST with other tools
=============================


.. toctree::
    :maxdepth: 1

    nest_server
    using_nest_with_music
