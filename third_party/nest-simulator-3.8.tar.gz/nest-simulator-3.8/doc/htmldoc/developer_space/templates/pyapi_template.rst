:orphan:

.. _pyapi_template:

PyNEST API template
===================

.. literalinclude:: pynest_api_template.py
