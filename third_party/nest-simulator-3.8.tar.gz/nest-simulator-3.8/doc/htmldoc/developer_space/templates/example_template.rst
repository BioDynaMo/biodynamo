:orphan:

.. _pyexample_template:

PyNEST example template
=======================


.. literalinclude:: pynest_example_template.py
