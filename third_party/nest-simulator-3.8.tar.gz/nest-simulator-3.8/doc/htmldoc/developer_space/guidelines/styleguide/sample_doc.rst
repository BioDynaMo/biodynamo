:orphan:

.. _sample_doc:

Main title of document
======================


.. _sec_my-ref-label:

Section to cross-reference
--------------------------

Some content in this section.



.. _eq_my-arbitrary-place-label:

.. math::

    E = mc^2
