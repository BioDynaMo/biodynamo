.. _sli_doc:

SLI documentation
=================


.. toctree::
   :maxdepth: 1

   an-introduction-to-sli
   first-steps
   neural-simulations
   objects-and-data-types
   programming-in-sli
   using-files-and-keyboard-input

