:orphan:

.. _behavior_index:

How NEST works
==============


.. toctree::

   built-in_timers
   random_numbers
   running_simulations
