Logic module
============

Given a condition, yields one value or another based on if the condition evaluates to true or false.

Syntax:
~~~~~~~~

::

   nest.logic.conditional(x, val_true, val_false)


.. automodule:: nest.logic.hl_api_logic
   :members:
   :undoc-members:
   :show-inheritance:
