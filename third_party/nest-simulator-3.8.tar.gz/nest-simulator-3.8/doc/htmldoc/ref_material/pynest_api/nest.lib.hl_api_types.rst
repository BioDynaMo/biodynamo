Types module
============

Accessing and setting node and parameter types in NEST.

.. automodule:: nest.lib.hl_api_types
   :members:
   :undoc-members:
   :show-inheritance:
