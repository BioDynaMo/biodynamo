Random module
=============

The random module contains random distributions that can be used to set
node and connection parameters, as well as positions for spatially distributed nodes.

Syntax::

   nest.random.uniform(min, max)

.. automodule:: nest.random.hl_api_random
   :members:
   :undoc-members:
   :show-inheritance:
