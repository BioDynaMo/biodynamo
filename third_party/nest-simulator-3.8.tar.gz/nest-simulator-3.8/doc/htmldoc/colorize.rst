:orphan:

.. Color profiles for Sphinx.
.. role:: maroon
.. role:: red
.. role:: magenta
.. role:: pink
.. role:: orange
.. role:: darkgreen
.. role:: green
.. role:: teal
.. role:: cyan
.. role:: aqua
.. role:: blue
.. role:: navy
.. role:: purple
.. role:: emph
.. role:: under
.. role:: over
.. role:: blink
.. role:: strike


.. Based on: (c) Lilian Besson, 2011-2016, https://bitbucket.org/lbesson/web-sphinx/

